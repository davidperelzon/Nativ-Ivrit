import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import TelaInicio from "../screens/TelaInicio";
import TelaAprendizado from "../screens/TelaAprendizado";
import TelaJogos from "../screens/TelaJogos";
import TelaEscuta from "../screens/TelaEscuta";
import TelaForum from "../screens/TelaForum";

const Tab = createBottomTabNavigator();

export default function NavegacaoAbas() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Início" component={TelaInicio} />
      <Tab.Screen name="Aprender" component={TelaAprendizado} />
      <Tab.Screen name="Jogos" component={TelaJogos} />
      <Tab.Screen name="Escuta" component={TelaEscuta} />
      <Tab.Screen name="Fórum" component={TelaForum} />
    </Tab.Navigator>
  );
}
