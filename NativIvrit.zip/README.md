# Nativ Ivrit
Estrutura inicial React Native.