import React, { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  Pressable,
  StyleSheet,
  StatusBar,
} from "react-native";

import AlfabetoHebraico from "./src/components/AlfabetoHebraico";
import ConteudoOriginal from "./src/components/ConteudoOriginal";

/*
 * App.js é o ponto de entrada da aplicação.
 *
 * A navegação principal foi mantida simples de propósito:
 * em vez de criar uma estrutura grande de navegadores, usamos useState
 * para controlar qual aba está aberta.
 *
 * Isso deixa o projeto fácil de entender para quem está começando
 * com React Native e também reduz a quantidade de dependências.
 */

const TABS = [
  {
    id: "alfabeto",
    titulo: "Alfabeto",
    icone: "א",
  },
  {
    id: "original",
    titulo: "Conteúdo",
    icone: "📚",
  },
];

export default function App() {
  // Guarda a aba principal atualmente selecionada.
  const [abaAtual, setAbaAtual] = useState("alfabeto");

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      {/* Cabeçalho fixo da aplicação. */}
      <View style={styles.header}>
        <View style={styles.logo}>
          <Text style={styles.logoTexto}>א</Text>
        </View>

        <View>
          <Text style={styles.titulo}>Nativ</Text>
          <Text style={styles.subtitulo}>עִבְרִית • Hebraico</Text>
        </View>
      </View>

      {/* Conteúdo da aba escolhida. */}
      <View style={styles.conteudo}>
        {abaAtual === "alfabeto" ? (
          <AlfabetoHebraico />
        ) : (
          <ConteudoOriginal />
        )}
      </View>

      {/* Barra inferior de abas. */}
      <View style={styles.tabBar}>
        {TABS.map((tab) => {
          const selecionada = abaAtual === tab.id;

          return (
            <Pressable
              key={tab.id}
              onPress={() => setAbaAtual(tab.id)}
              style={[
                styles.tabButton,
                selecionada && styles.tabButtonAtiva,
              ]}
            >
              <Text
                style={[
                  styles.tabIcone,
                  selecionada && styles.tabTextoAtivo,
                ]}
              >
                {tab.icone}
              </Text>

              <Text
                style={[
                  styles.tabTexto,
                  selecionada && styles.tabTextoAtivo,
                ]}
              >
                {tab.titulo}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },

  header: {
    height: 72,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E2E8F0",
  },

  logo: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: "#1E3A8A",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },

  logoTexto: {
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "700",
  },

  titulo: {
    color: "#111827",
    fontSize: 19,
    fontWeight: "700",
  },

  subtitulo: {
    color: "#64748B",
    fontSize: 12,
    marginTop: 2,
  },

  conteudo: {
    flex: 1,
  },

  tabBar: {
    height: 72,
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: "#E2E8F0",
  },

  tabButton: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 3,
  },

  tabButtonAtiva: {
    backgroundColor: "#EEF2FF",
  },

  tabIcone: {
    fontSize: 21,
    color: "#64748B",
  },

  tabTexto: {
    fontSize: 12,
    fontWeight: "600",
    color: "#64748B",
  },

  tabTextoAtivo: {
    color: "#1E3A8A",
  },
});
