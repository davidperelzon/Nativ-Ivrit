# Nativ - Minhas Telas

Projeto React Native/Expo reestruturado com duas abas principais.

## Abas

1. **Alfabeto** - ensino das 22 letras do alfabeto hebraico, com nome e transliteração.
2. **Conteúdo** - mantém os conceitos do projeto original: Início, Estudos, Exercícios, Fórum, Flashcards, Associações, Quiz, Vocabulário Esportivo e Pênaltis.

## Estrutura

```text
.
├── App.js
├── index.js
├── app.json
├── package.json
└── src
    └── components
        ├── AlfabetoHebraico.js
        └── ConteudoOriginal.js
```

## Rodar

```bash
npm install
npx expo start
```

O projeto evita bibliotecas de navegação para as abas principais. O estado da aba e das interações é controlado com `useState`, deixando a estrutura simples e fácil de estudar.
