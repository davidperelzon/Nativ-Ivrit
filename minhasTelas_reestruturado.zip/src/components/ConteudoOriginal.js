import React, { useEffect, useRef, useState } from "react";
import {
  ScrollView,
  View,
  Text,
  Pressable,
  TextInput,
  StyleSheet,
} from "react-native";

/*
 * Esta aba concentra os conceitos do projeto original.
 *
 * A versão enviada anteriormente tinha:
 * - início;
 * - trilha de estudos;
 * - exercícios;
 * - flashcards;
 * - associações;
 * - quiz de futebol;
 * - quiz rápido;
 * - pênaltis;
 * - fórum/comunidade.
 *
 * Tudo isso continua isolado nesta segunda aba.
 */

const CORES = {
  azul: "#1E3A8A",
  azulMedio: "#1D4ED8",
  azulClaro: "#EEF2FF",
  laranja: "#B45309",
  laranjaClaro: "#FEF3C7",
  marinho: "#111827",
  branco: "#FFFFFF",
  fundo: "#F8FAFC",
  borda: "#E2E8F0",
  cinza: "#64748B",
  cinzaClaro: "#F1F5F9",
  vermelho: "#DC2626",
};

const PALAVRAS = [
  { hebraico: "שָׁלוֹם", tr: "Shalom", pt: "Olá / Paz", emoji: "👋" },
  { hebraico: "תּוֹדָה", tr: "Todá", pt: "Obrigado/a", emoji: "🙏" },
  { hebraico: "בֹּקֶר טוֹב", tr: "Boker Tov", pt: "Bom dia", emoji: "☀️" },
  { hebraico: "לַיְלָה טוֹב", tr: "Laila Tov", pt: "Boa noite", emoji: "🌙" },
  { hebraico: "בְּבַקָּשָׁה", tr: "Bevakashá", pt: "Por favor", emoji: "🤲" },
  { hebraico: "סְלִיחָה", tr: "Slikhá", pt: "Com licença", emoji: "😅" },
  { hebraico: "כֵּן", tr: "Ken", pt: "Sim", emoji: "✅" },
  { hebraico: "לֹא", tr: "Lo", pt: "Não", emoji: "❌" },
  { hebraico: "מַיִם", tr: "Máyim", pt: "Água", emoji: "💧" },
  { hebraico: "לֶחֶם", tr: "Léchem", pt: "Pão", emoji: "🍞" },
  { hebraico: "בַּיִת", tr: "Báyit", pt: "Casa", emoji: "🏠" },
  { hebraico: "מִשְׁפָּחָה", tr: "Mishpahá", pt: "Família", emoji: "👨‍👩‍👧" },
];

const FUTEBOL = [
  { hebraico: "שַׁעַר", tr: "Sha'ar", pt: "Gol", emoji: "⚽" },
  { hebraico: "כַּדּוּר", tr: "Kadúr", pt: "Bola", emoji: "🟡" },
  { hebraico: "שָׂחְקָן", tr: "Sakhkán", pt: "Jogador", emoji: "🧑" },
  { hebraico: "אִצְטַדְיוֹן", tr: "Ítztadyon", pt: "Estádio", emoji: "🏟️" },
  { hebraico: "מְאַמֵּן", tr: "Me'amén", pt: "Treinador", emoji: "📋" },
  { hebraico: "נִצָּחוֹן", tr: "Nitsakhón", pt: "Vitória", emoji: "🏆" },
];

const RIDDLES = [
  {
    pergunta: "Olá / Paz",
    emoji: "👋",
    opcoes: ["שָׁלוֹם (Shalom)", "תּוֹדָה (Todá)", "כֵּן (Ken)", "לֹא (Lo)"],
    resposta: "שָׁלוֹם (Shalom)",
  },
  {
    pergunta: "Obrigado/a",
    emoji: "🙏",
    opcoes: ["בְּבַקָּשָׁה (Bevakashá)", "מַיִם (Máyim)", "תּוֹדָה (Todá)", "שָׁלוֹם (Shalom)"],
    resposta: "תּוֹדָה (Todá)",
  },
  {
    pergunta: "Água",
    emoji: "💧",
    opcoes: ["לֶחֶם (Léhem)", "מַיִם (Máim)", "בַּיִת (Báit)", "כֵּן (Ken)"],
    resposta: "מַיִם (Máim)",
  },
  {
    pergunta: "Gol!",
    emoji: "⚽",
    opcoes: ["כַּדּוּר (Kadúr)", "שָׂחְקָן (Sakhkán)", "שַׁעַר (Sha'ar)", "נִצָּחוֹן (Nitsakhón)"],
    resposta: "שַׁעַר (Sha'ar)",
  },
  {
    pergunta: "Vitória",
    emoji: "🏆",
    opcoes: ["שַׁעַר (Sha'ar)", "נִצָּחוֹן (Nitsakhón)", "מְאַמֵּן (Me'amén)", "כַּדּוּר (Kadúr)"],
    resposta: "נִצָּחוֹן (Nitsakhón)",
  },
];

const PENALTI_QUESTOES = [
  { hebraico: "שָׁלוֹם", tr: "Shalom", opcoes: ["Olá / Paz", "Obrigado", "Por favor", "Boa noite"], resposta: "Olá / Paz" },
  { hebraico: "תּוֹדָה", tr: "Todá", opcoes: ["Com licença", "Obrigado/a", "Sim", "Não"], resposta: "Obrigado/a" },
  { hebraico: "כֵּן", tr: "Ken", opcoes: ["Não", "Talvez", "Sim", "Por favor"], resposta: "Sim" },
  { hebraico: "לֹא", tr: "Lo", opcoes: ["Sim", "Não", "Água", "Casa"], resposta: "Não" },
  { hebraico: "מַיִם", tr: "Máim", opcoes: ["Pão", "Família", "Água", "Casa"], resposta: "Água" },
];

const NIVEIS = [
  {
    id: 1,
    nome: "Alef",
    descricao: "Fundamentos",
    icone: "📖",
    bloqueado: false,
    licoes: [
      { titulo: "Cumprimentos", icone: "👋", xp: 10 },
      { titulo: "Afirmações", icone: "✅", xp: 10 },
      { titulo: "Expressões", icone: "🙏", xp: 15 },
    ],
  },
  {
    id: 2,
    nome: "Bet",
    descricao: "Vocabulário",
    icone: "🏠",
    bloqueado: true,
    licoes: [
      { titulo: "Família", icone: "👨‍👩‍👧", xp: 15 },
      { titulo: "Alimentos", icone: "🍞", xp: 15 },
      { titulo: "Cores", icone: "🎨", xp: 20 },
    ],
  },
  {
    id: 3,
    nome: "Gimel",
    descricao: "Diálogos",
    icone: "💬",
    bloqueado: true,
    licoes: [
      { titulo: "Perguntas", icone: "❓", xp: 20 },
      { titulo: "Números", icone: "🔢", xp: 20 },
      { titulo: "Dias", icone: "📅", xp: 25 },
    ],
  },
  {
    id: 4,
    nome: "Dalet",
    descricao: "Intermediário",
    icone: "📚",
    bloqueado: true,
    licoes: [
      { titulo: "Verbos", icone: "🔤", xp: 30 },
      { titulo: "Esportes", icone: "⚽", xp: 30 },
      { titulo: "Cultura", icone: "🇮🇱", xp: 35 },
    ],
  },
];

const MENSAGENS_INICIAIS = [
  { id: 1, usuario: "Yael", avatar: "👩", mensagem: "Shalom! Alguém quer praticar?", horario: "09:12", minha: false },
  { id: 2, usuario: "Carlos", avatar: "👨", mensagem: "Shalom! Nível Bet. Posso tentar.", horario: "09:14", minha: false },
  { id: 3, usuario: "Ana", avatar: "👩", mensagem: "תּוֹדָה pela explicação de ontem.", horario: "09:20", minha: false },
  { id: 4, usuario: "Yael", avatar: "👩", mensagem: "בְּבַקָּשָׁה. Vamos continuar.", horario: "09:22", minha: false },
];

function embaralhar(lista) {
  return [...lista].sort(() => Math.random() - 0.5);
}

function BarraProgresso({ valor, maximo = 200 }) {
  const porcentagem = Math.min((valor / maximo) * 100, 100);

  return (
    <View style={styles.progressoFundo}>
      <View style={[styles.progressoValor, { width: `${porcentagem}%` }]} />
    </View>
  );
}

function CartaoJogo({ icone, titulo, descricao, cor, onPress }) {
  return (
    <Pressable onPress={onPress} style={styles.jogoCard}>
      <View style={[styles.jogoIcone, { backgroundColor: `${cor}18` }]}>
        <Text style={styles.jogoIconeTexto}>{icone}</Text>
      </View>

      <View style={styles.jogoInfo}>
        <Text style={styles.jogoTitulo}>{titulo}</Text>
        <Text style={styles.jogoDescricao}>{descricao}</Text>
      </View>

      <Text style={[styles.jogoSeta, { color: cor }]}>→</Text>
    </Pressable>
  );
}

function Inicio({ xp, abrirJogo }) {
  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <View style={styles.banner}>
        <Text style={styles.bannerTitulo}>Bem-vindo(a)</Text>

        <View style={styles.bannerLinha}>
          <Text style={styles.bannerNivel}>Nível Alef</Text>
          <Text style={styles.bannerXp}>{xp} XP</Text>
        </View>

        <BarraProgresso valor={xp} />
      </View>

      <View style={styles.card}>
        <Text style={styles.etiqueta}>VOCABULÁRIO DO DIA</Text>
        <Text style={styles.palavraDia}>מַה שְׁלוֹמְךָ?</Text>
        <Text style={styles.transliteracaoDia}>Ma Shlomhá?</Text>
        <Text style={styles.traducaoDia}>Como você está?</Text>
      </View>

      <Text style={styles.secaoTitulo}>Exercícios recomendados</Text>

      <CartaoJogo
        icone="📖"
        titulo="Flashcards"
        descricao="Memorização ativa"
        cor={CORES.azul}
        onPress={() => abrirJogo("flashcards")}
      />

      <CartaoJogo
        icone="🔗"
        titulo="Associações"
        descricao="Hebraico ↔ Português"
        cor={CORES.laranja}
        onPress={() => abrirJogo("associacoes")}
      />

      <CartaoJogo
        icone="❓"
        titulo="Quiz rápido"
        descricao="Teste de compreensão"
        cor={CORES.marinho}
        onPress={() => abrirJogo("quiz")}
      />

      <CartaoJogo
        icone="⚽"
        titulo="Pênaltis"
        descricao="Vocabulário + pressão"
        cor={CORES.laranja}
        onPress={() => abrirJogo("penaltis")}
      />
    </ScrollView>
  );
}

function Estudos({ xp, abrirJogo }) {
  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <Text style={styles.tituloPagina}>Trilha de Estudos</Text>
      <Text style={styles.subtituloPagina}>
        Progrida sistematicamente através dos níveis.
      </Text>

      <View style={styles.card}>
        <View style={styles.linhaEntre}>
          <Text style={styles.cardTitulo}>Progresso atual</Text>
          <Text style={styles.xpTexto}>{xp}/200 XP</Text>
        </View>

        <BarraProgresso valor={xp} />
      </View>

      {NIVEIS.map((nivel) => (
        <View key={nivel.id} style={styles.nivelBloco}>
          <View
            style={[
              styles.nivelCabecalho,
              nivel.bloqueado
                ? styles.nivelBloqueado
                : styles.nivelAtivo,
            ]}
          >
            <Text style={styles.nivelIcone}>
              {nivel.bloqueado ? "🔒" : nivel.icone}
            </Text>

            <View style={{ flex: 1 }}>
              <Text
                style={[
                  styles.nivelTitulo,
                  nivel.bloqueado && styles.textoBloqueado,
                ]}
              >
                Nível {nivel.id}: {nivel.nome}
              </Text>

              <Text
                style={[
                  styles.nivelDescricao,
                  nivel.bloqueado && styles.textoBloqueado,
                ]}
              >
                {nivel.descricao}
              </Text>
            </View>
          </View>

          {nivel.bloqueado ? (
            <View style={styles.bloqueioMensagem}>
              <Text style={styles.bloqueioTexto}>
                Complete o nível anterior.
              </Text>
            </View>
          ) : (
            nivel.licoes.map((licao) => (
              <Pressable
                key={licao.titulo}
                onPress={() => abrirJogo("flashcards")}
                style={styles.licaoCard}
              >
                <Text style={styles.licaoIcone}>{licao.icone}</Text>

                <View style={{ flex: 1 }}>
                  <Text style={styles.licaoTitulo}>{licao.titulo}</Text>
                  <Text style={styles.licaoXp}>{licao.xp} XP</Text>
                </View>

                <View style={styles.botaoIniciar}>
                  <Text style={styles.botaoIniciarTexto}>Iniciar</Text>
                </View>
              </Pressable>
            ))
          )}
        </View>
      ))}
    </ScrollView>
  );
}

function Exercicios({ abrirJogo }) {
  const jogos = [
    ["flashcards", "📖", "Flashcards", "Memorização sistemática", CORES.azul],
    ["associacoes", "🔗", "Associações", "Relacionar palavras", CORES.laranja],
    ["quiz", "❓", "Compreensão", "Teste de múltipla escolha", CORES.marinho],
    ["penaltis", "⚽", "Pênaltis", "Desafio sob pressão", CORES.laranja],
    ["futebol", "🏟️", "Vocabulário Esportivo", "Termos de futebol", "#1E40AF"],
  ];

  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <Text style={styles.tituloPagina}>Exercícios</Text>
      <Text style={styles.subtituloPagina}>
        Pratique e ganhe experiência.
      </Text>

      {jogos.map(([id, icone, titulo, descricao, cor]) => (
        <CartaoJogo
          key={id}
          icone={icone}
          titulo={titulo}
          descricao={descricao}
          cor={cor}
          onPress={() => abrirJogo(id)}
        />
      ))}
    </ScrollView>
  );
}

function Forum() {
  const [mensagens, setMensagens] = useState(MENSAGENS_INICIAIS);
  const [texto, setTexto] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollToEnd({ animated: true });
  }, [mensagens]);

  function enviarMensagem() {
    const mensagemLimpa = texto.trim();

    if (!mensagemLimpa) {
      return;
    }

    const agora = new Date().toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });

    setMensagens((atual) => [
      ...atual,
      {
        id: Date.now(),
        usuario: "Você",
        avatar: "👤",
        mensagem: mensagemLimpa,
        horario: agora,
        minha: true,
      },
    ]);

    setTexto("");

    // Simula uma resposta local para manter o fórum funcional
    // mesmo sem um servidor/backend.
    setTimeout(() => {
      setMensagens((atual) => [
        ...atual,
        {
          id: Date.now() + 1,
          usuario: "Yael",
          avatar: "👩",
          mensagem: "Shalom! Bom progresso.",
          horario: new Date().toLocaleTimeString("pt-BR", {
            hour: "2-digit",
            minute: "2-digit",
          }),
          minha: false,
        },
      ]);
    }, 800);
  }

  return (
    <View style={styles.forum}>
      <View style={styles.forumCabecalho}>
        <Text style={styles.forumTitulo}>Fórum da Comunidade</Text>
        <Text style={styles.forumMembros}>● 42 membros ativos</Text>
      </View>

      <ScrollView
        ref={scrollRef}
        style={styles.mensagens}
        contentContainerStyle={{ padding: 16 }}
      >
        {mensagens.map((item) => (
          <View
            key={item.id}
            style={[
              styles.mensagemLinha,
              item.minha && styles.mensagemMinha,
            ]}
          >
            {!item.minha && (
              <View style={styles.avatar}>
                <Text>{item.avatar}</Text>
              </View>
            )}

            <View style={styles.mensagemArea}>
              {!item.minha && (
                <Text style={styles.mensagemUsuario}>
                  {item.usuario}
                </Text>
              )}

              <View
                style={[
                  styles.mensagemBalao,
                  item.minha && styles.mensagemBalaoMinha,
                ]}
              >
                <Text
                  style={[
                    styles.mensagemTexto,
                    item.minha && styles.mensagemTextoMinha,
                  ]}
                >
                  {item.mensagem}
                </Text>
              </View>

              <Text style={styles.horario}>{item.horario}</Text>
            </View>
          </View>
        ))}
      </ScrollView>

      <View style={styles.compositor}>
        <TextInput
          value={texto}
          onChangeText={setTexto}
          placeholder="Digite sua mensagem..."
          placeholderTextColor="#94A3B8"
          style={styles.input}
          returnKeyType="send"
          onSubmitEditing={enviarMensagem}
        />

        <Pressable
          onPress={enviarMensagem}
          disabled={!texto.trim()}
          style={[
            styles.enviar,
            !texto.trim() && styles.enviarDesativado,
          ]}
        >
          <Text style={styles.enviarTexto}>→</Text>
        </Pressable>
      </View>
    </View>
  );
}

function Flashcards({ voltar, adicionarXp }) {
  const [indice, setIndice] = useState(0);
  const [virado, setVirado] = useState(false);
  const [conhecidas, setConhecidas] = useState([]);

  const palavra = PALAVRAS[indice];

  function proxima(conhece) {
    if (conhece && !conhecidas.includes(indice)) {
      setConhecidas((atual) => [...atual, indice]);
      adicionarXp(3);
    }

    setIndice((atual) => (atual + 1) % PALAVRAS.length);
    setVirado(false);
  }

  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <BotaoVoltar voltar={voltar} titulo="Flashcards" />

      <Text style={styles.contador}>
        Flashcard {indice + 1}/{PALAVRAS.length}
      </Text>

      <Pressable
        onPress={() => setVirado((atual) => !atual)}
        style={styles.flashcard}
      >
        {!virado ? (
          <>
            <Text style={styles.flashEtiqueta}>HEBRAICO</Text>
            <Text style={styles.flashHebraico}>{palavra.hebraico}</Text>
            <Text style={styles.flashTr}>{palavra.tr}</Text>
          </>
        ) : (
          <>
            <Text style={styles.flashEtiqueta}>PORTUGUÊS</Text>
            <Text style={styles.flashPortugues}>{palavra.pt}</Text>
            <Text style={styles.flashHebraicoPequeno}>
              {palavra.hebraico}
            </Text>
          </>
        )}
      </Pressable>

      {!virado ? (
        <View style={styles.instrucao}>
          <Text style={styles.instrucaoTexto}>
            Toque no cartão para ver a tradução.
          </Text>
        </View>
      ) : (
        <View style={styles.duasColunas}>
          <Pressable
            onPress={() => proxima(false)}
            style={styles.botaoNaoSei}
          >
            <Text style={styles.botaoNaoSeiTexto}>Não sei</Text>
          </Pressable>

          <Pressable
            onPress={() => proxima(true)}
            style={styles.botaoConheco}
          >
            <Text style={styles.botaoConhecoTexto}>Conheço</Text>
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}

function Associacoes({ voltar, adicionarXp }) {
  const [pares] = useState(() => embaralhar(PALAVRAS).slice(0, 5));
  const [selecionado, setSelecionado] = useState(null);
  const [concluidos, setConcluidos] = useState([]);
  const [erro, setErro] = useState(null);

  function selecionar(item, tipo) {
    if (concluidos.includes(item.hebraico)) {
      return;
    }

    const atual = { ...item, tipo };

    if (!selecionado) {
      setSelecionado(atual);
      return;
    }

    if (
      selecionado.hebraico === item.hebraico &&
      selecionado.tipo !== tipo
    ) {
      setConcluidos((atualLista) => [
        ...atualLista,
        item.hebraico,
      ]);
      adicionarXp(4);
      setSelecionado(null);
      return;
    }

    if (selecionado.tipo === tipo) {
      setSelecionado(atual);
      return;
    }

    setErro(item.hebraico);
    setTimeout(() => setErro(null), 500);
    setSelecionado(null);
  }

  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <BotaoVoltar voltar={voltar} titulo="Associações" />

      <Text style={styles.subtituloPagina}>
        Conecte as palavras equivalentes.
      </Text>

      {pares.map((item) => (
        <View key={item.hebraico} style={styles.parLinha}>
          <Pressable
            onPress={() => selecionar(item, "hebraico")}
            style={[
              styles.parBotao,
              selecionado?.hebraico === item.hebraico &&
                selecionado?.tipo === "hebraico" &&
                styles.parSelecionado,
              concluidos.includes(item.hebraico) &&
                styles.parConcluido,
              erro === item.hebraico && styles.parErro,
            ]}
          >
            <Text style={styles.parHebraico}>{item.hebraico}</Text>
            <Text style={styles.parTr}>{item.tr}</Text>
          </Pressable>

          <Pressable
            onPress={() => selecionar(item, "portugues")}
            style={[
              styles.parBotao,
              selecionado?.hebraico === item.hebraico &&
                selecionado?.tipo === "portugues" &&
                styles.parSelecionadoLaranja,
              concluidos.includes(item.hebraico) &&
                styles.parConcluido,
            ]}
          >
            <Text style={styles.parEmoji}>{item.emoji}</Text>
            <Text style={styles.parPortugues}>{item.pt}</Text>
          </Pressable>
        </View>
      ))}

      {concluidos.length === pares.length && (
        <View style={styles.resultado}>
          <Text style={styles.resultadoEmoji}>🎉</Text>
          <Text style={styles.resultadoTitulo}>Tudo certo!</Text>
          <Text style={styles.resultadoTexto}>
            Você associou todos os pares.
          </Text>
        </View>
      )}
    </ScrollView>
  );
}

function Quiz({ voltar, adicionarXp }) {
  const [indice, setIndice] = useState(0);
  const [resposta, setResposta] = useState(null);
  const [pontos, setPontos] = useState(0);

  const pergunta = RIDDLES[indice];

  function responder(opcao) {
    if (resposta) {
      return;
    }

    setResposta(opcao);

    if (opcao === pergunta.resposta) {
      setPontos((atual) => atual + 1);
      adicionarXp(5);
    }
  }

  function proxima() {
    if (indice < RIDDLES.length - 1) {
      setIndice((atual) => atual + 1);
      setResposta(null);
    }
  }

  const finalizado =
    indice === RIDDLES.length - 1 && resposta !== null;

  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <BotaoVoltar voltar={voltar} titulo="Quiz rápido" />

      <View style={styles.quizCabecalho}>
        <Text style={styles.quizPontos}>
          {pontos}/{RIDDLES.length}
        </Text>
        <Text style={styles.quizContador}>
          {indice + 1}/{RIDDLES.length}
        </Text>
      </View>

      <View style={styles.quizPergunta}>
        <Text style={styles.quizEmoji}>{pergunta.emoji}</Text>
        <Text style={styles.quizTexto}>
          Como se diz "{pergunta.pergunta}"?
        </Text>
      </View>

      {pergunta.opcoes.map((opcao) => {
        const correta = opcao === pergunta.resposta;
        const selecionada = opcao === resposta;

        return (
          <Pressable
            key={opcao}
            disabled={!!resposta}
            onPress={() => responder(opcao)}
            style={[
              styles.opcao,
              resposta && correta && styles.opcaoCorreta,
              resposta && selecionada && !correta && styles.opcaoErrada,
            ]}
          >
            <Text
              style={[
                styles.opcaoTexto,
                /[א-ת]/.test(opcao) && styles.opcaoHebraico,
              ]}
            >
              {opcao}
            </Text>
          </Pressable>
        );
      })}

      {resposta && (
        <Pressable
          onPress={proxima}
          disabled={finalizado}
          style={styles.botaoProximo}
        >
          <Text style={styles.botaoProximoTexto}>
            {finalizado ? `Finalizado • ${pontos}/${RIDDLES.length}` : "Próxima"}
          </Text>
        </Pressable>
      )}
    </ScrollView>
  );
}

function FutebolQuiz({ voltar, adicionarXp }) {
  const [indice, setIndice] = useState(0);
  const [resposta, setResposta] = useState(null);
  const [pontos, setPontos] = useState(0);

  const atual = FUTEBOL[indice];

  const opcoes = embaralhar([
    atual,
    ...embaralhar(FUTEBOL.filter((_, index) => index !== indice)).slice(0, 3),
  ]);

  function responder(opcao) {
    if (resposta) {
      return;
    }

    setResposta(opcao.pt);

    if (opcao.pt === atual.pt) {
      setPontos((valor) => valor + 1);
      adicionarXp(5);
    }
  }

  function proxima() {
    if (indice < FUTEBOL.length - 1) {
      setIndice((valor) => valor + 1);
      setResposta(null);
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.pagina}>
      <BotaoVoltar voltar={voltar} titulo="Vocabulário Esportivo" />

      <View style={styles.futebolCabecalho}>
        <Text style={styles.futebolPontos}>
          ⚽ {pontos}/{FUTEBOL.length}
        </Text>
      </View>

      <View style={styles.futebolPergunta}>
        <Text style={styles.futebolHebraico}>{atual.hebraico}</Text>
        <Text style={styles.futebolTr}>{atual.tr}</Text>
      </View>

      {opcoes.map((opcao) => {
        const correta = opcao.pt === atual.pt;
        const selecionada = resposta === opcao.pt;

        return (
          <Pressable
            key={opcao.pt}
            disabled={!!resposta}
            onPress={() => responder(opcao)}
            style={[
              styles.opcao,
              resposta && correta && styles.opcaoCorreta,
              resposta && selecionada && !correta && styles.opcaoErrada,
            ]}
          >
            <Text style={styles.opcaoEmoji}>{opcao.emoji}</Text>
            <Text style={styles.opcaoTexto}>{opcao.pt}</Text>
          </Pressable>
        );
      })}

      {resposta && (
        <Pressable
          onPress={proxima}
          style={styles.botaoProximo}
        >
          <Text style={styles.botaoProximoTexto}>
            {indice < FUTEBOL.length - 1 ? "Continuar" : "Finalizar"}
          </Text>
        </Pressable>
      )}
    </ScrollView>
  );
}

function Penaltis({ voltar, adicionarXp }) {
  const [indice, setIndice] = useState(0);
  const [resposta, setResposta] = useState(null);
  const [gols, setGols] = useState(0);
  const [finalizado, setFinalizado] = useState(false);

  const perguntas = PENALTI_QUESTOES;
  const atual = perguntas[indice];

  function responder(opcao) {
    if (resposta || finalizado) {
      return;
    }

    const correta = opcao === atual.resposta;
    setResposta(opcao);

    // A resposta certa dá uma chance maior de gol.
    // A interação é propositalmente simples para funcionar sem SVG
    // ou bibliotecas extras.
    if (correta) {
      setGols((valor) => valor + 1);
      adicionarXp(5);
    }
  }

  function proximoChute() {
    if (indice < perguntas.length - 1) {
      setIndice((valor) => valor + 1);
      setResposta(null);
    } else {
      setFinalizado(true);
    }
  }

  if (finalizado) {
    return (
      <ScrollView contentContainerStyle={styles.penaltiFinal}>
        <BotaoVoltar voltar={voltar} titulo="Pênaltis Hebraicos" />

        <Text style={styles.penaltiEmoji}>🏆</Text>
        <Text style={styles.penaltiResultado}>
          {gols}/{perguntas.length}
        </Text>

        <Text style={styles.penaltiTitulo}>
          {gols >= 3 ? "Boa partida!" : "Continue praticando!"}
        </Text>

        <Pressable
          onPress={() => {
            setIndice(0);
            setResposta(null);
            setGols(0);
            setFinalizado(false);
          }}
          style={styles.botaoProximo}
        >
          <Text style={styles.botaoProximoTexto}>
            Jogar novamente
          </Text>
        </Pressable>
      </ScrollView>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.penaltiPagina}>
      <BotaoVoltar voltar={voltar} titulo="Pênaltis Hebraicos" />

      <View style={styles.campo}>
        <Text style={styles.trave}>🥅</Text>
        <Text style={styles.bola}>⚽</Text>
      </View>

      <Text style={styles.penaltiPlacar}>
        Gol: {gols} • Chute {indice + 1}/{perguntas.length}
      </Text>

      <View style={styles.penaltiPergunta}>
        <Text style={styles.penaltiHebraico}>{atual.hebraico}</Text>
        <Text style={styles.penaltiTr}>{atual.tr}</Text>
        <Text style={styles.penaltiInstrucao}>
          Qual é a tradução?
        </Text>
      </View>

      {atual.opcoes.map((opcao) => {
        const correta = opcao === atual.resposta;
        const selecionada = opcao === resposta;

        return (
          <Pressable
            key={opcao}
            disabled={!!resposta}
            onPress={() => responder(opcao)}
            style={[
              styles.penaltiOpcao,
              resposta && correta && styles.penaltiCorreta,
              resposta && selecionada && !correta && styles.penaltiErrada,
            ]}
          >
            <Text style={styles.penaltiOpcaoTexto}>{opcao}</Text>
          </Pressable>
        );
      })}

      {resposta && (
        <View style={styles.penaltiFeedback}>
          <Text style={styles.penaltiFeedbackTexto}>
            {resposta === atual.resposta
              ? "⚽ GOL! Resposta correta."
              : `🧤 Defesa! Era "${atual.resposta}".`}
          </Text>

          <Pressable
            onPress={proximoChute}
            style={styles.botaoProximo}
          >
            <Text style={styles.botaoProximoTexto}>
              {indice < perguntas.length - 1
                ? "Próximo chute"
                : "Finalizar"}
            </Text>
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}

function BotaoVoltar({ voltar, titulo }) {
  return (
    <View style={styles.topoInterno}>
      <Pressable onPress={voltar} style={styles.voltar}>
        <Text style={styles.voltarTexto}>← Voltar</Text>
      </Pressable>

      <Text style={styles.topoTitulo}>{titulo}</Text>
    </View>
  );
}

export default function ConteudoOriginal() {
  const [secao, setSecao] = useState("inicio");
  const [xp, setXp] = useState(120);

  function adicionarXp(valor) {
    setXp((atual) => atual + valor);
  }

  function abrirJogo(jogo) {
    setSecao(jogo);
  }

  function voltarInicio() {
    setSecao("inicio");
  }

  if (secao === "flashcards") {
    return (
      <Flashcards
        voltar={voltarInicio}
        adicionarXp={adicionarXp}
      />
    );
  }

  if (secao === "associacoes") {
    return (
      <Associacoes
        voltar={voltarInicio}
        adicionarXp={adicionarXp}
      />
    );
  }

  if (secao === "quiz") {
    return (
      <Quiz
        voltar={voltarInicio}
        adicionarXp={adicionarXp}
      />
    );
  }

  if (secao === "futebol") {
    return (
      <FutebolQuiz
        voltar={voltarInicio}
        adicionarXp={adicionarXp}
      />
    );
  }

  if (secao === "penaltis") {
    return (
      <Penaltis
        voltar={voltarInicio}
        adicionarXp={adicionarXp}
      />
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.subTabs}>
        {[
          ["inicio", "🏠", "Início"],
          ["estudos", "📚", "Estudos"],
          ["exercicios", "🎯", "Exercícios"],
          ["forum", "💬", "Fórum"],
        ].map(([id, icone, titulo]) => {
          const ativa = secao === id;

          return (
            <Pressable
              key={id}
              onPress={() => setSecao(id)}
              style={[
                styles.subTab,
                ativa && styles.subTabAtiva,
              ]}
            >
              <Text style={styles.subTabIcone}>{icone}</Text>
              <Text
                style={[
                  styles.subTabTexto,
                  ativa && styles.subTabTextoAtivo,
                ]}
              >
                {titulo}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {secao === "inicio" && (
        <Inicio xp={xp} abrirJogo={abrirJogo} />
      )}

      {secao === "estudos" && (
        <Estudos xp={xp} abrirJogo={abrirJogo} />
      )}

      {secao === "exercicios" && (
        <Exercicios abrirJogo={abrirJogo} />
      )}

      {secao === "forum" && <Forum />}
    </View>
  );
}

const styles = StyleSheet.create({
  pagina: {
    padding: 18,
    paddingBottom: 30,
  },

  banner: {
    backgroundColor: CORES.azul,
    borderRadius: 20,
    padding: 22,
    marginBottom: 16,
  },

  bannerTitulo: {
    color: "#FFFFFF",
    fontSize: 25,
    fontWeight: "700",
    marginBottom: 16,
  },

  bannerLinha: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 9,
  },

  bannerNivel: {
    color: "#DBEAFE",
    fontSize: 13,
    fontWeight: "600",
  },

  bannerXp: {
    color: "#FCD34D",
    fontSize: 13,
    fontWeight: "700",
  },

  progressoFundo: {
    height: 7,
    backgroundColor: "#FFFFFF30",
    borderRadius: 99,
    overflow: "hidden",
  },

  progressoValor: {
    height: "100%",
    backgroundColor: "#FCD34D",
    borderRadius: 99,
  },

  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: CORES.borda,
    padding: 18,
    marginBottom: 20,
  },

  etiqueta: {
    color: CORES.cinza,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1,
    marginBottom: 10,
  },

  palavraDia: {
    color: CORES.marinho,
    fontSize: 34,
    fontWeight: "700",
    textAlign: "right",
    marginBottom: 4,
  },

  transliteracaoDia: {
    color: CORES.laranja,
    fontSize: 16,
    fontWeight: "700",
  },

  traducaoDia: {
    color: CORES.cinza,
    fontSize: 14,
    marginTop: 3,
  },

  secaoTitulo: {
    color: CORES.marinho,
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 12,
  },

  tituloPagina: {
    color: CORES.marinho,
    fontSize: 23,
    fontWeight: "700",
    marginBottom: 5,
  },

  subtituloPagina: {
    color: CORES.cinza,
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 18,
  },

  jogoCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    borderWidth: 1,
    borderColor: CORES.borda,
    padding: 16,
    marginBottom: 11,
  },

  jogoIcone: {
    width: 54,
    height: 54,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 13,
  },

  jogoIconeTexto: {
    fontSize: 25,
  },

  jogoInfo: {
    flex: 1,
  },

  jogoTitulo: {
    color: CORES.marinho,
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 3,
  },

  jogoDescricao: {
    color: CORES.cinza,
    fontSize: 13,
  },

  jogoSeta: {
    fontSize: 20,
    fontWeight: "700",
    marginLeft: 8,
  },

  linhaEntre: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },

  cardTitulo: {
    color: CORES.marinho,
    fontSize: 14,
    fontWeight: "700",
  },

  xpTexto: {
    color: CORES.laranja,
    fontSize: 14,
    fontWeight: "700",
  },

  nivelBloco: {
    marginBottom: 18,
  },

  nivelCabecalho: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 13,
    padding: 15,
    marginBottom: 9,
  },

  nivelAtivo: {
    backgroundColor: CORES.azul,
  },

  nivelBloqueado: {
    backgroundColor: CORES.cinzaClaro,
  },

  nivelIcone: {
    fontSize: 24,
    marginRight: 12,
  },

  nivelTitulo: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "700",
  },

  nivelDescricao: {
    color: "#DBEAFE",
    fontSize: 13,
    marginTop: 2,
  },

  textoBloqueado: {
    color: CORES.cinza,
  },

  licaoCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 12,
    padding: 13,
    marginBottom: 8,
  },

  licaoIcone: {
    fontSize: 22,
    width: 44,
    textAlign: "center",
  },

  licaoTitulo: {
    color: CORES.marinho,
    fontSize: 14,
    fontWeight: "700",
  },

  licaoXp: {
    color: CORES.cinza,
    fontSize: 12,
    marginTop: 2,
  },

  botaoIniciar: {
    backgroundColor: CORES.azul,
    borderRadius: 8,
    paddingVertical: 7,
    paddingHorizontal: 10,
  },

  botaoIniciarTexto: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "700",
  },

  bloqueioMensagem: {
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: CORES.borda,
    borderRadius: 12,
    padding: 14,
    alignItems: "center",
  },

  bloqueioTexto: {
    color: CORES.cinza,
    fontSize: 13,
    fontWeight: "600",
  },

  subTabs: {
    height: 58,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: CORES.borda,
    flexDirection: "row",
  },

  subTab: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  subTabAtiva: {
    backgroundColor: CORES.azulClaro,
  },

  subTabIcone: {
    fontSize: 17,
  },

  subTabTexto: {
    color: CORES.cinza,
    fontSize: 10,
    fontWeight: "600",
    marginTop: 2,
  },

  subTabTextoAtivo: {
    color: CORES.azul,
  },

  topoInterno: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
  },

  voltar: {
    backgroundColor: CORES.azulClaro,
    borderRadius: 9,
    paddingVertical: 8,
    paddingHorizontal: 11,
    marginRight: 12,
  },

  voltarTexto: {
    color: CORES.azul,
    fontSize: 13,
    fontWeight: "700",
  },

  topoTitulo: {
    color: CORES.marinho,
    fontSize: 20,
    fontWeight: "700",
  },

  contador: {
    color: CORES.cinza,
    fontSize: 13,
    fontWeight: "600",
    marginBottom: 12,
  },

  flashcard: {
    height: 270,
    backgroundColor: CORES.azul,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
    marginBottom: 15,
  },

  flashEtiqueta: {
    color: "#BFDBFE",
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1,
    marginBottom: 12,
  },

  flashHebraico: {
    color: "#FFFFFF",
    fontSize: 48,
    fontWeight: "700",
    textAlign: "center",
  },

  flashTr: {
    color: "#FCD34D",
    fontSize: 18,
    fontWeight: "700",
    marginTop: 8,
  },

  flashPortugues: {
    color: "#FFFFFF",
    fontSize: 28,
    fontWeight: "700",
    textAlign: "center",
  },

  flashHebraicoPequeno: {
    color: "#DBEAFE",
    fontSize: 22,
    marginTop: 12,
  },

  instrucao: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: CORES.borda,
    padding: 15,
    alignItems: "center",
  },

  instrucaoTexto: {
    color: CORES.cinza,
    fontSize: 13,
    fontWeight: "600",
  },

  duasColunas: {
    flexDirection: "row",
    gap: 10,
  },

  botaoNaoSei: {
    flex: 1,
    borderWidth: 1,
    borderColor: CORES.vermelho,
    borderRadius: 12,
    padding: 15,
    alignItems: "center",
  },

  botaoNaoSeiTexto: {
    color: CORES.vermelho,
    fontWeight: "700",
  },

  botaoConheco: {
    flex: 1,
    backgroundColor: CORES.azul,
    borderRadius: 12,
    padding: 15,
    alignItems: "center",
  },

  botaoConhecoTexto: {
    color: "#FFFFFF",
    fontWeight: "700",
  },

  parLinha: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 10,
  },

  parBotao: {
    flex: 1,
    minHeight: 78,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
  },

  parSelecionado: {
    borderColor: CORES.azul,
    backgroundColor: CORES.azulClaro,
  },

  parSelecionadoLaranja: {
    borderColor: CORES.laranja,
    backgroundColor: CORES.laranjaClaro,
  },

  parConcluido: {
    borderColor: "#D97706",
    backgroundColor: "#FEF3C7",
  },

  parErro: {
    borderColor: CORES.vermelho,
  },

  parHebraico: {
    color: CORES.marinho,
    fontSize: 20,
    fontWeight: "700",
  },

  parTr: {
    color: CORES.cinza,
    fontSize: 10,
    marginTop: 2,
  },

  parEmoji: {
    fontSize: 22,
  },

  parPortugues: {
    color: CORES.marinho,
    fontSize: 12,
    fontWeight: "700",
    textAlign: "center",
    marginTop: 3,
  },

  resultado: {
    backgroundColor: CORES.azulClaro,
    borderRadius: 16,
    padding: 22,
    alignItems: "center",
    marginTop: 10,
  },

  resultadoEmoji: {
    fontSize: 48,
  },

  resultadoTitulo: {
    color: CORES.azul,
    fontSize: 21,
    fontWeight: "700",
    marginTop: 8,
  },

  resultadoTexto: {
    color: CORES.cinza,
    fontSize: 13,
    marginTop: 3,
  },

  quizCabecalho: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 14,
  },

  quizPontos: {
    color: CORES.azul,
    fontSize: 16,
    fontWeight: "700",
  },

  quizContador: {
    color: CORES.cinza,
    fontSize: 13,
    fontWeight: "600",
  },

  quizPergunta: {
    backgroundColor: CORES.azul,
    borderRadius: 16,
    padding: 22,
    alignItems: "center",
    marginBottom: 14,
  },

  quizEmoji: {
    fontSize: 38,
    marginBottom: 10,
  },

  quizTexto: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "700",
    textAlign: "center",
    lineHeight: 23,
  },

  opcao: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    alignItems: "center",
  },

  opcaoCorreta: {
    backgroundColor: "#F0FDF4",
    borderColor: "#059669",
  },

  opcaoErrada: {
    backgroundColor: "#FEF2F2",
    borderColor: CORES.vermelho,
  },

  opcaoTexto: {
    color: CORES.marinho,
    fontSize: 14,
    fontWeight: "600",
    textAlign: "center",
  },

  opcaoHebraico: {
    fontSize: 17,
  },

  opcaoEmoji: {
    fontSize: 22,
    marginBottom: 3,
  },

  botaoProximo: {
    backgroundColor: CORES.azul,
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    marginTop: 5,
  },

  botaoProximoTexto: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
  },

  futebolCabecalho: {
    backgroundColor: "#F0FDF4",
    borderRadius: 12,
    padding: 12,
    marginBottom: 14,
  },

  futebolPontos: {
    color: "#059669",
    fontSize: 16,
    fontWeight: "700",
  },

  futebolPergunta: {
    backgroundColor: "#059669",
    borderRadius: 16,
    padding: 25,
    alignItems: "center",
    marginBottom: 14,
  },

  futebolHebraico: {
    color: "#FFFFFF",
    fontSize: 44,
    fontWeight: "700",
  },

  futebolTr: {
    color: "#D1FAE5",
    fontSize: 16,
    fontWeight: "700",
    marginTop: 5,
  },

  forum: {
    flex: 1,
  },

  forumCabecalho: {
    backgroundColor: "#FFFFFF",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: CORES.borda,
  },

  forumTitulo: {
    color: CORES.marinho,
    fontSize: 18,
    fontWeight: "700",
  },

  forumMembros: {
    color: CORES.cinza,
    fontSize: 12,
    marginTop: 4,
  },

  mensagens: {
    flex: 1,
    backgroundColor: CORES.fundo,
  },

  mensagemLinha: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 12,
  },

  mensagemMinha: {
    flexDirection: "row-reverse",
  },

  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: CORES.azulClaro,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 9,
  },

  mensagemArea: {
    maxWidth: "78%",
  },

  mensagemUsuario: {
    color: CORES.cinza,
    fontSize: 11,
    fontWeight: "700",
    marginBottom: 4,
  },

  mensagemBalao: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 15,
    padding: 12,
  },

  mensagemBalaoMinha: {
    backgroundColor: CORES.laranjaClaro,
    borderColor: CORES.laranja,
  },

  mensagemTexto: {
    color: CORES.marinho,
    fontSize: 14,
    lineHeight: 19,
  },

  mensagemTextoMinha: {
    color: CORES.laranja,
  },

  horario: {
    color: "#94A3B8",
    fontSize: 10,
    marginTop: 3,
  },

  compositor: {
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: CORES.borda,
    padding: 12,
    gap: 9,
  },

  input: {
    flex: 1,
    minHeight: 46,
    backgroundColor: CORES.cinzaClaro,
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 12,
    paddingHorizontal: 13,
    color: CORES.marinho,
  },

  enviar: {
    width: 46,
    height: 46,
    backgroundColor: CORES.azul,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },

  enviarDesativado: {
    backgroundColor: CORES.cinzaClaro,
  },

  enviarTexto: {
    color: "#FFFFFF",
    fontSize: 20,
    fontWeight: "700",
  },

  campo: {
    height: 150,
    backgroundColor: "#166534",
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 14,
    overflow: "hidden",
  },

  trave: {
    fontSize: 68,
  },

  bola: {
    fontSize: 32,
    position: "absolute",
    bottom: 20,
  },

  penaltiPlacar: {
    color: CORES.marinho,
    fontSize: 15,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 14,
  },

  penaltiPergunta: {
    backgroundColor: CORES.azul,
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
    marginBottom: 14,
  },

  penaltiHebraico: {
    color: "#FFFFFF",
    fontSize: 43,
    fontWeight: "700",
  },

  penaltiTr: {
    color: "#FCD34D",
    fontSize: 17,
    fontWeight: "700",
    marginTop: 4,
  },

  penaltiInstrucao: {
    color: "#DBEAFE",
    fontSize: 13,
    marginTop: 10,
  },

  penaltiOpcao: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: CORES.borda,
    borderRadius: 12,
    padding: 15,
    marginBottom: 9,
    alignItems: "center",
  },

  penaltiCorreta: {
    backgroundColor: "#FEF3C7",
    borderColor: "#D97706",
  },

  penaltiErrada: {
    backgroundColor: "#FEF2F2",
    borderColor: CORES.vermelho,
  },

  penaltiOpcaoTexto: {
    color: CORES.marinho,
    fontSize: 14,
    fontWeight: "600",
    textAlign: "center",
  },

  penaltiFeedback: {
    marginTop: 5,
  },

  penaltiFeedbackTexto: {
    color: CORES.marinho,
    textAlign: "center",
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 10,
  },

  penaltiFinal: {
    flexGrow: 1,
    padding: 18,
    alignItems: "center",
    justifyContent: "center",
  },

  penaltiEmoji: {
    fontSize: 72,
    marginTop: 25,
  },

  penaltiResultado: {
    color: CORES.azul,
    fontSize: 46,
    fontWeight: "700",
    marginTop: 10,
  },

  penaltiTitulo: {
    color: CORES.marinho,
    fontSize: 21,
    fontWeight: "700",
    marginVertical: 10,
  },

  penaltiPagina: {
    padding: 18,
    paddingBottom: 30,
  },
});
