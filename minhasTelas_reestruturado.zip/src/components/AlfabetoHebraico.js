import React, { useState } from "react";
import {
  ScrollView,
  View,
  Text,
  Pressable,
  StyleSheet,
} from "react-native";

/*
 * As 22 letras do alfabeto hebraico.
 *
 * Cada objeto possui:
 * - letra: caractere hebraico;
 * - nome: nome tradicional da letra;
 * - transliteracao: forma aproximada usada para estudar o som.
 *
 * As cinco formas finais aparecem na seção abaixo porque são formas
 * especiais usadas no final de palavras.
 */
const LETRAS = [
  { letra: "א", nome: "Alef", transliteracao: "— / som de vogal" },
  { letra: "ב", nome: "Bet", transliteracao: "B / V" },
  { letra: "ג", nome: "Gimel", transliteracao: "G" },
  { letra: "ד", nome: "Dalet", transliteracao: "D" },
  { letra: "ה", nome: "He", transliteracao: "H" },
  { letra: "ו", nome: "Vav", transliteracao: "V / U / O" },
  { letra: "ז", nome: "Zayin", transliteracao: "Z" },
  { letra: "ח", nome: "Het", transliteracao: "H gutural" },
  { letra: "ט", nome: "Tet", transliteracao: "T" },
  { letra: "י", nome: "Yod", transliteracao: "Y / I" },
  { letra: "כ", nome: "Kaf", transliteracao: "K / Kh" },
  { letra: "ל", nome: "Lamed", transliteracao: "L" },
  { letra: "מ", nome: "Mem", transliteracao: "M" },
  { letra: "נ", nome: "Nun", transliteracao: "N" },
  { letra: "ס", nome: "Samekh", transliteracao: "S" },
  { letra: "ע", nome: "Ayin", transliteracao: "— / som gutural" },
  { letra: "פ", nome: "Pe", transliteracao: "P / F" },
  { letra: "צ", nome: "Tsadi", transliteracao: "TS" },
  { letra: "ק", nome: "Qof", transliteracao: "K" },
  { letra: "ר", nome: "Resh", transliteracao: "R" },
  { letra: "ש", nome: "Shin", transliteracao: "SH / S" },
  { letra: "ת", nome: "Tav", transliteracao: "T" },
];

const FORMAS_FINAIS = [
  { letra: "ך", nome: "Kaf final", origem: "כ" },
  { letra: "ם", nome: "Mem final", origem: "מ" },
  { letra: "ן", nome: "Nun final", origem: "נ" },
  { letra: "ף", nome: "Pe final", origem: "פ" },
  { letra: "ץ", nome: "Tsadi final", origem: "צ" },
];

export default function AlfabetoHebraico() {
  // Guarda qual letra está selecionada para mostrar uma explicação maior.
  const [letraSelecionada, setLetraSelecionada] = useState(LETRAS[0]);

  return (
    <ScrollView
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.hero}>
        <Text style={styles.heroLetra}>א</Text>

        <View style={styles.heroTexto}>
          <Text style={styles.heroTitulo}>
            Ensino do Alfabeto Hebraico
          </Text>

          <Text style={styles.heroDescricao}>
            Aprenda as letras, os nomes e uma transliteração aproximada
            para facilitar o primeiro contato com o hebraico.
          </Text>
        </View>
      </View>

      <View style={styles.cardDestaque}>
        <Text style={styles.cardEtiqueta}>LETRA SELECIONADA</Text>

        <Text style={styles.letraGrande}>
          {letraSelecionada.letra}
        </Text>

        <Text style={styles.nomeGrande}>
          {letraSelecionada.nome}
        </Text>

        <Text style={styles.somGrande}>
          Transliteração: {letraSelecionada.transliteracao}
        </Text>
      </View>

      <Text style={styles.secaoTitulo}>As 22 letras</Text>

      <Text style={styles.secaoDescricao}>
        Toque em uma letra para ver o nome e a transliteração.
      </Text>

      <View style={styles.grid}>
        {LETRAS.map((item) => {
          const selecionada =
            letraSelecionada.letra === item.letra;

          return (
            <Pressable
              key={item.letra}
              onPress={() => setLetraSelecionada(item)}
              style={[
                styles.letraCard,
                selecionada && styles.letraCardAtiva,
              ]}
            >
              <Text
                style={[
                  styles.letra,
                  selecionada && styles.letraAtiva,
                ]}
              >
                {item.letra}
              </Text>

              <Text
                style={[
                  styles.nome,
                  selecionada && styles.nomeAtivo,
                ]}
              >
                {item.nome}
              </Text>

              <Text
                style={[
                  styles.transliteracao,
                  selecionada && styles.transliteracaoAtiva,
                ]}
              >
                {item.transliteracao}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={styles.cardFinais}>
        <Text style={styles.secaoTitulo}>Formas finais</Text>

        <Text style={styles.secaoDescricao}>
          Algumas letras mudam de formato quando aparecem no final
          de uma palavra.
        </Text>

        <View style={styles.finaisLista}>
          {FORMAS_FINAIS.map((item) => (
            <View key={item.letra} style={styles.finalItem}>
              <Text style={styles.finalLetra}>{item.letra}</Text>

              <View style={styles.finalTexto}>
                <Text style={styles.finalNome}>{item.nome}</Text>
                <Text style={styles.finalOrigem}>
                  Forma de {item.origem}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.dica}>
        <Text style={styles.dicaIcone}>💡</Text>

        <View style={{ flex: 1 }}>
          <Text style={styles.dicaTitulo}>Dica de estudo</Text>

          <Text style={styles.dicaTexto}>
            Estude poucas letras por vez. Primeiro reconheça o formato,
            depois memorize o nome e por último pratique a transliteração.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 18,
    paddingBottom: 28,
  },

  hero: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1E3A8A",
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
  },

  heroLetra: {
    color: "#FFFFFF",
    fontSize: 56,
    fontWeight: "700",
    marginRight: 16,
  },

  heroTexto: {
    flex: 1,
  },

  heroTitulo: {
    color: "#FFFFFF",
    fontSize: 21,
    fontWeight: "700",
    marginBottom: 7,
  },

  heroDescricao: {
    color: "#DBEAFE",
    fontSize: 13,
    lineHeight: 19,
  },

  cardDestaque: {
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    alignItems: "center",
    padding: 22,
    marginBottom: 24,
  },

  cardEtiqueta: {
    color: "#64748B",
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1,
  },

  letraGrande: {
    color: "#1E3A8A",
    fontSize: 62,
    fontWeight: "700",
    marginTop: 5,
  },

  nomeGrande: {
    color: "#111827",
    fontSize: 22,
    fontWeight: "700",
    marginTop: 3,
  },

  somGrande: {
    color: "#D97706",
    fontSize: 14,
    fontWeight: "600",
    marginTop: 6,
    textAlign: "center",
  },

  secaoTitulo: {
    color: "#111827",
    fontSize: 20,
    fontWeight: "700",
  },

  secaoDescricao: {
    color: "#64748B",
    fontSize: 13,
    lineHeight: 19,
    marginTop: 5,
    marginBottom: 14,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },

  letraCard: {
    width: "31.5%",
    minHeight: 124,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    padding: 9,
    marginBottom: 10,
  },

  letraCardAtiva: {
    backgroundColor: "#EEF2FF",
    borderColor: "#1D4ED8",
  },

  letra: {
    fontSize: 34,
    color: "#1E3A8A",
    fontWeight: "700",
  },

  letraAtiva: {
    color: "#1D4ED8",
  },

  nome: {
    color: "#111827",
    fontSize: 12,
    fontWeight: "700",
    marginTop: 5,
    textAlign: "center",
  },

  nomeAtivo: {
    color: "#1E3A8A",
  },

  transliteracao: {
    color: "#64748B",
    fontSize: 10,
    textAlign: "center",
    marginTop: 4,
  },

  transliteracaoAtiva: {
    color: "#D97706",
    fontWeight: "700",
  },

  cardFinais: {
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    padding: 18,
    marginTop: 14,
  },

  finaisLista: {
    gap: 8,
  },

  finalItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F8FAFC",
    borderRadius: 12,
    padding: 10,
  },

  finalLetra: {
    width: 50,
    color: "#1E3A8A",
    fontSize: 30,
    textAlign: "center",
    fontWeight: "700",
  },

  finalTexto: {
    marginLeft: 8,
  },

  finalNome: {
    color: "#111827",
    fontSize: 14,
    fontWeight: "700",
  },

  finalOrigem: {
    color: "#64748B",
    fontSize: 12,
    marginTop: 2,
  },

  dica: {
    flexDirection: "row",
    backgroundColor: "#FEF3C7",
    borderRadius: 16,
    padding: 16,
    marginTop: 16,
  },

  dicaIcone: {
    fontSize: 24,
    marginRight: 10,
  },

  dicaTitulo: {
    color: "#92400E",
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 4,
  },

  dicaTexto: {
    color: "#78350F",
    fontSize: 13,
    lineHeight: 18,
  },
});
