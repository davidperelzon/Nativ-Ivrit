import { registerRootComponent } from "expo";
import App from "./App";

/*
 * O Expo usa este arquivo para registrar o componente principal.
 */
registerRootComponent(App);
